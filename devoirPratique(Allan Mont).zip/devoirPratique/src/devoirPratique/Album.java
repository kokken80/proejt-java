package devoirPratique;

import java.sql.*;

public class Album {
    private int id;            // Identifiant unique de l'album
    private String nom;        // Nom de l'album
    private String artiste;    // Artiste de l'album

   
    // Constructeur avec paramètres
    public Album(int id, String nom, String artiste) {
        this.id = id;
        this.nom = nom;
        this.artiste = artiste;
    }

    // Getter 
    public int getId() {
        return id;
    }

   
    

    public String getNom() {
        return nom;
    }

    
    

    public String getArtiste() {
        return artiste;
    }

   
    

    // Sauvegarder un album dans la base de données
    public void save() {
        String query = "INSERT INTO Albums (nom, artiste) VALUES (?, ?)";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, this.nom);
            stmt.setString(2, this.artiste);

            stmt.executeUpdate();
            System.out.println("Album ajouté avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour rechercher un album par son nom
    public static Album trouverParNom(String nom) {
        String query = "SELECT * FROM Albums WHERE nom = ?";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nom);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String artiste = rs.getString("artiste");
                return new Album(id, nom, artiste); // Retourne l'album trouvé
            } else {
                System.out.println("Aucun album trouvé avec ce nom.");
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
 // Méthode pour afficher les chansons d'un album
    public void afficherChansons() {
        String query = "SELECT * FROM Chansons WHERE album_id = ?";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, this.id); // Utilisation de l'ID de l'album actuel
            ResultSet rs = stmt.executeQuery();

            boolean chansonsTrouvees = false;  // Indicateur pour savoir si des chansons sont trouvées

            while (rs.next()) {
                chansonsTrouvees = true;
                String titreChanson = rs.getString("titre");
                String artisteChanson = rs.getString("artiste");
                String genreChanson = rs.getString("genre");
                int dureeChanson = rs.getInt("duree");

                System.out.println("Chanson: " + titreChanson + " - Artiste: " + artisteChanson + 
                                   " - Genre: " + genreChanson + " - Durée: " + dureeChanson + " secondes");
            }

            if (!chansonsTrouvees) {
                System.out.println("Aucune chanson trouvée pour cet album.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


 // Méthode pour afficher tous les albums et leurs chansons
    public static void afficherTousLesAlbumsEtChansons() {
        String query = "SELECT id, nom, artiste FROM Albums";  // Récupérer l'ID, le nom et l'artiste
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idAlbum = rs.getInt("id");  // Récupérer l'ID de l'album
                String nomAlbum = rs.getString("nom");
                String artisteAlbum = rs.getString("artiste");

                // Créez un objet Album avec l'ID pour la logique mais sans l'afficher
                Album album = new Album(idAlbum, nomAlbum, artisteAlbum);

                // Affichez les informations de l'album (sans afficher l'ID)
                System.out.println("Album: " + nomAlbum + " - Artiste: " + artisteAlbum);

                // Affichez les chansons de l'album
                album.afficherChansons();  // Appelle la méthode pour afficher les chansons de l'album
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
