package devoirPratique;

import java.sql.*;

public class Chanson {
    private int id;          // Identifiant unique
    private String titre;    // Titre de la chanson
    private String artiste;  // Artiste de la chanson
    private String genre;    // Genre musical
    private int duree;       // Durée en secondes
    private int albumId;     // Référence à l'album

    // Constructeur avec paramètres
    public Chanson(int id, String titre, String artiste, String genre, int duree, int albumId) {
        this.titre = titre;
        this.artiste = artiste;
        this.genre = genre;
        this.duree = duree;
        this.albumId = albumId;
    }

    // Getter 
    public int getId() {
        return id;
    }

    

    public String getTitre() {
        return titre;
    }

    

    public String getArtiste() {
        return artiste;
    }

    

    public String getGenre() {
        return genre;
    }

   

    public int getDuree() {
        return duree;
    }

   

    public int getAlbumId() {
        return albumId;
    }

  

    // Sauvegarder une chanson dans la base de données
    public void save() {
        String query = "INSERT INTO Chansons (titre, artiste, genre, duree, album_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, this.titre);
            stmt.setString(2, this.artiste);
            stmt.setString(3, this.genre);
            stmt.setInt(4, this.duree);
            stmt.setInt(5, this.albumId);

            stmt.executeUpdate();
            System.out.println("Chanson ajoutée avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
 // Méthode pour rechercher des chansons par genre
    public static void rechercherParGenre(String genre) {
        String query = "SELECT * FROM Chansons WHERE genre = ?";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, genre); // Paramètre pour le genre de la chanson
            ResultSet rs = stmt.executeQuery();

            boolean chansonsTrouvees = false;  // Indicateur pour savoir si des chansons sont trouvées

            while (rs.next()) {
                chansonsTrouvees = true;
                String titreChanson = rs.getString("titre");
                String artisteChanson = rs.getString("artiste");
                int dureeChanson = rs.getInt("duree");
                

               
                // Affichage des informations de la chanson
                System.out.println("Chanson: " + titreChanson + " - Artiste: " + artisteChanson + 
                                   " - Genre: " + genre + " - Durée: " + dureeChanson + " secondes");

                }

            if (!chansonsTrouvees) {
                System.out.println("Aucune chanson trouvée pour ce genre.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
 // Méthode pour rechercher des chansons dont la durée est inférieure ou égale à une durée maximale
    public static void rechercherParDureeMaximale(int dureeMaximale) {
        String query = "SELECT * FROM Chansons WHERE duree <= ?";
        try (Connection conn = ConnexionBaseDeDonnees.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, dureeMaximale); // Paramètre pour la durée maximale
            ResultSet rs = stmt.executeQuery();

            boolean chansonsTrouvees = false;  // Indicateur pour savoir si des chansons sont trouvées

            while (rs.next()) {
                chansonsTrouvees = true;
                String titreChanson = rs.getString("titre");
                String artisteChanson = rs.getString("artiste");
                int dureeChanson = rs.getInt("duree");
               

                // Affichage des informations de la chanson
                System.out.println("Chanson: " + titreChanson + " - Artiste: " + artisteChanson + 
                                   " - Durée: " + dureeChanson + " secondes");

               
            }

            if (!chansonsTrouvees) {
                System.out.println("Aucune chanson trouvée avec une durée inférieure ou égale à " + dureeMaximale + " secondes.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
