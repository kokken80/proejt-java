package devoirPratique;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choix;

        while (true) {
            // Affichage du menu
            System.out.println("----- Menu -----");
            System.out.println("1. Ajouter un album");
            System.out.println("2. Ajouter une chanson à un album");
            System.out.println("3. Afficher les chansons d'un album");
            System.out.println("4. Créer une chanson indépendamment d'un album");
            System.out.println("5. Afficher tous les albums et leurs chansons");
            System.out.println("6. Rechercher des chansons par genre");
            System.out.println("7. Rechercher des chansons par durée maximale");
            System.out.println("8. Quitter");
            System.out.print("Choisissez une option (1-8) : ");
            // Vérification de l'entrée utilisateur
            if (scanner.hasNextInt()) {
                choix = scanner.nextInt();
                scanner.nextLine(); // Consomme le retour à la ligne après nextInt()
            } else {
                System.out.println("Entrée invalide. Veuillez entrer un numéro entre 1 et 8.");
                scanner.nextLine(); // Consomme la ligne d'entrée incorrecte
                continue; // Recommence la boucle sans faire d'action supplémentaire
            }

            switch (choix) {
                case 1:
                    // Ajouter un album
                    System.out.print("Entrez le nom de l'album : ");
                    String nomAlbum = scanner.nextLine();
                    System.out.print("Entrez le nom de l'artiste : ");
                    String artisteAlbum = scanner.nextLine();
                    Album album = new Album(0, nomAlbum, artisteAlbum);
                    album.save(); // Ajoute l'album à la base de données
                    break;

                case 2:
                    // Ajouter une chanson à un album
                    System.out.print("Entrez le nom de l'album auquel ajouter la chanson : ");
                    String nomAlbumRecherche = scanner.nextLine();
                    Album albumRecherche = Album.trouverParNom(nomAlbumRecherche); // Recherche l'album par son nom
                    
                    if (albumRecherche != null) {
                        System.out.print("Entrez le titre de la chanson : ");
                        String titreChanson = scanner.nextLine();
                        System.out.print("Entrez le nom de l'artiste de la chanson : ");
                        String artisteChanson = scanner.nextLine();
                        System.out.print("Entrez le genre de la chanson : ");
                        String genreChanson = scanner.nextLine();
                        System.out.print("Entrez la durée de la chanson en secondes : ");
                        int dureeChanson = scanner.nextInt();
                        scanner.nextLine(); // Consomme le retour à la ligne après nextInt()

                        Chanson chanson = new Chanson(0, titreChanson, artisteChanson, genreChanson, dureeChanson, albumRecherche.getId());
                        chanson.save(); // Ajoute la chanson à l'album
                    } else {
                        System.out.println("L'album avec le nom '" + nomAlbumRecherche + "' n'a pas été trouvé.");
                    }
                    break;

                case 3:
                    // Afficher les chansons d'un album par son nom
                    System.out.print("Entrez le nom de l'album pour afficher ses chansons : ");
                    String nomAlbumAffichage = scanner.nextLine();
                    Album albumAffichage = Album.trouverParNom(nomAlbumAffichage); // Recherche l'album par son nom
                    if (albumAffichage != null) {
                        albumAffichage.afficherChansons(); // Affiche les chansons de l'album
                    }
                    break;

                case 4:
                    // Créer une chanson indépendamment d'un album
                    System.out.print("Entrez le titre de la chanson : ");
                    String titreChansonIndependant = scanner.nextLine();
                    System.out.print("Entrez le nom de l'artiste de la chanson : ");
                    String artisteChansonIndependant = scanner.nextLine();
                    System.out.print("Entrez le genre de la chanson : ");
                    String genreChansonIndependant = scanner.nextLine();
                    System.out.print("Entrez la durée de la chanson en secondes : ");
                    int dureeChansonIndependant = scanner.nextInt();
                    scanner.nextLine(); // Consomme le retour à la ligne après nextInt()

                    // Créer une chanson sans l'associer à un album (ID de l'album à 0 ou null)
                    Chanson chansonIndependant = new Chanson(0, titreChansonIndependant, artisteChansonIndependant, genreChansonIndependant, dureeChansonIndependant, 0);
                    chansonIndependant.save(); // Ajoute la chanson à la base de données
                    break;

                case 5:
                    // Afficher tous les albums et leurs chansons
                    Album.afficherTousLesAlbumsEtChansons();
                    break;

                case 6:
                    // Rechercher des chansons par genre
                    System.out.print("Entrez le genre de chanson à rechercher : ");
                    String genreRecherche = scanner.nextLine();
                    Chanson.rechercherParGenre(genreRecherche); // Recherche les chansons par genre
                    break;

                case 7:
                    // Rechercher des chansons par durée maximale
                    System.out.print("Entrez la durée maximale des chansons (en secondes) : ");
                    int dureeMaximale = scanner.nextInt();
                    scanner.nextLine(); // Consomme le retour à la ligne après nextInt()
                    Chanson.rechercherParDureeMaximale(dureeMaximale); // Recherche les chansons par durée
                    break;

                case 8:
                    // Quitter
                    System.out.println("fait par le fan de JAVA  !");
                    scanner.close();
                    return; // Quitte le programme

                default:
                    System.out.println("Option invalide, veuillez entrer un numéro entre 1 et 8.");
            }
        }
    }
}
