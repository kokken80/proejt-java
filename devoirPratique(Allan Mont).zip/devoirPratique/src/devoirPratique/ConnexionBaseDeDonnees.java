package devoirPratique;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnexionBaseDeDonnees {
public static Connection getConnection() {
try {
return DriverManager.getConnection("jdbc:mysql:///devoirpratique", "root", "");
} catch (SQLException e) {
System.out.println("Problème de connexion à la base de données.");
return null; // ou lancez une exception selon votre gestion d'erreur
}
}
}