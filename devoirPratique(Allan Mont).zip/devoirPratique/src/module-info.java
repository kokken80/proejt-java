/**
 * 
 */
/**
 * 
 */
module devoirPratique {
	requires java.sql;
}